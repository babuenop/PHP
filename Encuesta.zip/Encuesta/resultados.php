<HTML LANG="ES">
<HEAD>
	<TITLE>Encuesta</title>
	<Link REL="stylesheet" TYPE="TEXT/css" href="bootstrap/css/bootstrap.min.css">
</HEAD>
<body>



<?php 
include "navbar.php"; 

print ("<div class=container>");
	print("<div class=row>");
		print("<div class=col-md-6>");
			print("<H1>Resultados</H1>");
		
		print("</div>");
	print("</div>");
print("</div>");
?>

<?php
require('conexion.php');
$instruccion = "CALL sp_listar_resultados ();";
$consulta = mysqli_query ($conexion, $instruccion)
	or die("Fallo en la consulta ". mysqli_error($conexion));
$nfilas = mysqli_num_rows($consulta);

if($nfilas > 0)
{
	
	for ($i=1; $i<=$nfilas; $i++)
	{
		$resultado = mysqli_fetch_array($consulta);
		$votos1=$resultado ['votos1'];
		$votos2=$resultado ['votos2'];
		$votos3=$resultado ['votos3'];
		$votos4=$resultado ['votos4'];
		$votos5=$resultado ['votos5'];
		$votos6=$resultado ['votos6'];
		
		$totalVotos = $votos1 + $votos2 + $votos3 + $votos4+ $votos5+ $votos6;
		print("<FORM action=registrarVoto.php method=POST>");
		print("<div class=container>");
		print("<div class=row>

			
		<br>");
		print("<h4>Pregunta ".$resultado ['idpregunta'] ."<h4>");
		print("<h5>Total Votos ".$totalVotos ."<h5>");
		
		
		print ("<TABLE>\n");
		
		print ("<TR>\n");
		print ("<TH>Respuesta</TH>\n");
		print ("<TH>Votos</TH>\n");
		print ("<TH>Porcentaje</TH>\n");
		print ("<TH>Representacion Grafica</TH>\n");	
		print ("</TR>\n");
		$porcentaje = round (($votos1/$totalVotos)*100.2);
		print ("<TR>\n");
		print ("<TD CLASS='izquierda'> opcion 1</TD>\n");
		print ("<TD CLASS='derecha'>$votos1</TD>\n");
		print ("<TD CLASS='derecha'>$porcentaje%</TD>\n");
		print ("<TD CLASS='izquierda' WIDTH='400'><IMG SRC='img/puntoamarillo.gif' HEIGHT='10' WIDTH='".$porcentaje*4 . "'></TD>\n");	
		print ("</TR>\n");
		$porcentaje = round (($votos2/$totalVotos)*100.2);
		print ("<tr>\n");
		print ("<TD CLASS='izquierda'> opcion 2</TD>\n");
		print ("<TD CLASS='derecha'>$votos2</TD>\n");
		print ("<TD CLASS='derecha'>$porcentaje%</TD>\n");
		print ("<TD CLASS='izquierda' WIDTH='400'><IMG SRC='img/puntoamarillo.gif' HEIGHT='10' WIDTH='".$porcentaje*4 . "'></TD>\n");	
		print ("</TR>\n");
		
		$porcentaje = round (($votos3/$totalVotos)*100.2);
		print ("<tr>\n");
		print ("<TD CLASS='izquierda'> opcion 3</TD>\n");
		print ("<TD CLASS='derecha'>$votos2</TD>\n");
		print ("<TD CLASS='derecha'>$porcentaje%</TD>\n");
		print ("<TD CLASS='izquierda' WIDTH='400'><IMG SRC='img/puntoamarillo.gif' HEIGHT='10' WIDTH='".$porcentaje*4 . "'></TD>\n");	
		print ("</TR>\n");
		$porcentaje = round (($votos4/$totalVotos)*100.2);
		print ("<tr>\n");
		print ("<TD CLASS='izquierda'> opcion 4</TD>\n");
		print ("<TD CLASS='derecha'>$votos2</TD>\n");
		print ("<TD CLASS='derecha'>$porcentaje%</TD>\n");
		print ("<TD CLASS='izquierda' WIDTH='400'><IMG SRC='img/puntoamarillo.gif' HEIGHT='10' WIDTH='".$porcentaje*4 . "'></TD>\n");	
		print ("</TR>\n");
		$porcentaje = round (($votos5/$totalVotos)*100.2);
		print ("<tr>\n");
		print ("<TD CLASS='izquierda'> opcion 5</TD>\n");
		print ("<TD CLASS='derecha'>$votos2</TD>\n");
		print ("<TD CLASS='derecha'>$porcentaje%</TD>\n");
		print ("<TD CLASS='izquierda' WIDTH='400'><IMG SRC='img/puntoamarillo.gif' HEIGHT='10' WIDTH='".$porcentaje*4 . "'></TD>\n");	
		print ("</TR>\n");
		$porcentaje = round (($votos6/$totalVotos)*100.2);
		print ("<tr>\n");
		print ("<TD CLASS='izquierda'> opcion 6</TD>\n");
		print ("<TD CLASS='derecha'>$votos2</TD>\n");
		print ("<TD CLASS='derecha'>$porcentaje%</TD>\n");
		print ("<TD CLASS='izquierda' WIDTH='400'><IMG SRC='img/puntoamarillo.gif' HEIGHT='10' WIDTH='".$porcentaje*4 . "'></TD>\n");	
		print ("</TR>\n");
		
		print ("</TABLE>\n");
		print ("<p>Numero total de votos emitidos: $totalVotos </P>\n");
		
		
		print("</form>");
	}
	
}
else
{
	print("<h3>No hay preguntas disponibles<h3>");
}

mysqli_close($conexion)

?>

</BODY>
</HTML>
	