<?php
$host="localhost";
$user="root";
$password="";
$db="labsbd";
$con = new mysqli($host,$user,$password,$db);
?>